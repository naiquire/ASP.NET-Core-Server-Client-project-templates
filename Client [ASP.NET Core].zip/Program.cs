﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR.Client;

namespace $safeprojectname$
{
    internal class Program
    {
        // defines connections which are each set up with unique URLs
        public struct _connections
        {
            public HubConnection subclass1 { get; set; }
            public HubConnection subclass2 { get; set; }
            public HubConnection subclass3 { get; set; }
        }

        static void Main(string[] args)
        {
            Connection connection = new Connection();

            // initialise required connections
            _connections _connections = new _connections
            {
                subclass1 = connection.initialiseConnection("http://0.0.0.0:5252/subdomain/class1"),
                subclass2 = connection.initialiseConnection("http://0.0.0.0:5252/subdomain/class2"),
                subclass3 = connection.initialiseConnection("http://0.0.0.0:5252/subdomain/class3")
            };

            // start connections
            connection.startConnection(_connections.subclass1);
            connection.startConnection(_connections.subclass2);
            connection.startConnection(_connections.subclass3);

            #region Handle connection loss
            _connections.subclass1.Closed += async (error) =>
            {
                Console.WriteLine($"Connection closed: {error?.Message}");
                await Task.Delay(0);
            };
            _connections.subclass2.Closed += async (error) =>
            {
                Console.WriteLine($"Connection closed: {error?.Message}");
                await Task.Delay(0);
            };
            _connections.subclass3.Closed += async (error) =>
            {
                Console.WriteLine($"Connection closed: {error?.Message}");
                await Task.Delay(0);
            };
            #endregion

            // add handles to connections
            connection.connectionHandles(_connections.subclass1);
            connection.connectionHandles(_connections.subclass2);
            connection.connectionHandles(_connections.subclass3);
        }
    }
}
