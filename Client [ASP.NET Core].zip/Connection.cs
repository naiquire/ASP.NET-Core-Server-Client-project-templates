﻿using System;
using Microsoft.AspNetCore.SignalR.Client;

namespace $safeprojectname$
{
    internal class Connection
    {
        public HubConnection initialiseConnection(string serverURL)
        {
            HubConnection connection = new HubConnectionBuilder()
                .WithUrl(serverURL, options =>
                {
                    options.Transports = Microsoft.AspNetCore.Http.Connections.HttpTransportType.WebSockets |
                                         Microsoft.AspNetCore.Http.Connections.HttpTransportType.ServerSentEvents |
                                         Microsoft.AspNetCore.Http.Connections.HttpTransportType.LongPolling;
                })
                .Build();
            return connection;
        }
        public async void startConnection(HubConnection _connection)
        {
            try
            {
                await _connection.StartAsync();
                // subroutines on server can be called here if required
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to connect: {ex.Message}");
            }
        }
        public void connectionHandles(HubConnection _connection)
        {
            _connection.On<string>("unique_identifier", async (sent_data) =>
            {
                // ideally call a subroutine in Program

                // send data back to the server
                await _connection.SendAsync("unique_identifier", sent_data);
            });
        }
    }
}
