﻿using Microsoft.AspNetCore.SignalR;

namespace $safeprojectname$.Subdomains
{
    public class @class : Hub
    {
        // example class for routing a request
        // runs after a request to http://0.0.0.0:5252/subdomain/class

        public class @subclass : Hub
        {
            // handles http://0.0.0.0:5252/subdomain/class/subclass
            // unlikely to be required
        }
    }
}
