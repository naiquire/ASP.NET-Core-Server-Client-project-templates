﻿using Microsoft.AspNetCore.SignalR;

namespace $safeprojectname$.Subdomains
{
    public class @class2 : Hub
    {
        // example class for routing a request
        // runs after a request to http://0.0.0.0:5252/subdomain/class2

        public class @subclass : Hub
        {
            // handles http://0.0.0.0:5252/subdomain/class2/subclass
            // unlikely to be required
        }
    }
}
