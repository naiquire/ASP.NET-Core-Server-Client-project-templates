
// install packages if required
// update line 61 to run the server on a specific port for the class
// update lines 50-54 to redirect requests into the correct subclass

namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.ConfigureServices(services =>
                    {
                        services.AddSignalR();
                        services.AddEndpointsApiExplorer();
                        services.AddSwaggerGen();

                        services.AddCors(options =>
                        {
                            options.AddPolicy("AllowAll", policy =>
                            {
                                policy.AllowAnyOrigin()
                                      .AllowAnyMethod()
                                      .AllowAnyHeader();
                            });
                        });
                    })

                    .Configure(app =>
                    {
                        app.UseRouting();
                        app.UseCors("AllowAll");
                        app.Use(async (context, next) =>
                        {
                            await next.Invoke();
                        });
                        app.UseEndpoints(endpoints =>
                        {
                            // subdomain specifies the application required for the request (automatically handled by NGINX)
                            // class specifies the type of request to the application
                            // subclass specifies any further details

                            endpoints.MapHub<Subdomains.@class>("/subdomain/class/");
                            endpoints.MapHub<Subdomains.@class.@subclass>("/subdomain/class/subclass/");

                            endpoints.MapHub<Subdomains.@class2>("/subdomain/class2/");
                            endpoints.MapHub<Subdomains.@class2.@subclass>("/subdomain/class2/subclass/");
                        });
                    })

                    // ensure port is not used elsewhere
                    // port number is linked to the subdomain such that only requests to :5252/subdomain are forwarded to :5000

                    .UseUrls("http://0.0.0.0:5000");

                });
    }
}
